"""
CSV I/O helpers.
Safe reading and writing of claims CSV files and output CSV.
"""

import csv
import os


# Exact column order for output.csv — hardcoded per spec
OUTPUT_COLUMNS = [
    "user_id", "image_paths", "user_claim", "claim_object",
    "evidence_standard_met", "evidence_standard_met_reason",
    "risk_flags", "issue_type", "object_part", "claim_status",
    "claim_status_justification", "supporting_image_ids",
    "valid_image", "severity"
]


def read_claims(filepath: str) -> list[dict]:
    """
    Read claims.csv or sample_claims.csv.
    Returns list of row dicts with all fields as strings.
    """
    rows = []
    with open(filepath, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Strip whitespace from keys and values
            cleaned = {k.strip(): v.strip() if v else "" for k, v in row.items()}
            rows.append(cleaned)
    return rows


def read_user_history(filepath: str) -> dict[str, dict]:
    """
    Read user_history.csv.
    Returns dict keyed by user_id, with each value being the full row dict.
    """
    history = {}
    with open(filepath, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cleaned = {k.strip(): v.strip() if v else "" for k, v in row.items()}
            user_id = cleaned.get("user_id", "")
            if user_id:
                history[user_id] = cleaned
    return history


def write_output(rows: list[dict], filepath: str):
    """
    Write output.csv with exact column order.
    Always quote all string fields using QUOTE_ALL.
    """
    # Ensure directory exists
    out_dir = os.path.dirname(filepath)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=OUTPUT_COLUMNS,
            quoting=csv.QUOTE_ALL,
            extrasaction="ignore"
        )
        writer.writeheader()
        for row in rows:
            # Ensure all columns exist in the row
            safe_row = {col: row.get(col, "") for col in OUTPUT_COLUMNS}
            writer.writerow(safe_row)
