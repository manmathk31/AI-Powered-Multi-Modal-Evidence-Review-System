# Multi-Modal Evidence Review — Solution

## Setup
1. Clone the repo
2. cd into repo root
3. pip install -r code/requirements.txt
4. cp code/.env.example .env and add your GEMINI_API_KEY

## Run predictions
```
python code/main.py
```

## Run evaluation (sample set)
```
python code/evaluation/main.py
```

## Output
output.csv — predictions for all rows in dataset/claims.csv

## Notes
- Uses Google Gemini 1.5 Flash (free tier)
- Responses cached in .cache/ to avoid duplicate API calls
- Log written to ~/hackerrank_orchestrate/log.txt
