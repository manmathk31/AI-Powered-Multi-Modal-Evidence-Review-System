"""
Evaluation metrics module.
Computes per-field accuracy scores comparing predicted vs expected values.
"""


def accuracy(predicted: list[str], expected: list[str]) -> float:
    """
    Compute simple accuracy: fraction of exact matches.

    Args:
        predicted: list of predicted values
        expected: list of expected values

    Returns:
        Accuracy as a float between 0.0 and 1.0
    """
    if not expected:
        return 0.0
    correct = sum(1 for p, e in zip(predicted, expected) if p.strip().lower() == e.strip().lower())
    return correct / len(expected)


def jaccard_similarity(predicted_flags: list[str], expected_flags: list[str]) -> float:
    """
    Compute average Jaccard similarity for risk_flags across all rows.
    Each row's flags are semicolon-separated sets.

    Args:
        predicted_flags: list of semicolon-separated flag strings
        expected_flags: list of semicolon-separated flag strings

    Returns:
        Mean Jaccard similarity across all rows
    """
    if not expected_flags:
        return 0.0

    similarities = []
    for pred_str, exp_str in zip(predicted_flags, expected_flags):
        pred_set = _parse_flags(pred_str)
        exp_set = _parse_flags(exp_str)

        if not pred_set and not exp_set:
            # Both empty (or both "none") — perfect match
            similarities.append(1.0)
        elif not pred_set or not exp_set:
            similarities.append(0.0)
        else:
            intersection = pred_set & exp_set
            union = pred_set | exp_set
            similarities.append(len(intersection) / len(union) if union else 0.0)

    return sum(similarities) / len(similarities)


def _parse_flags(flags_str: str) -> set[str]:
    """Parse a semicolon-separated flags string into a set, treating 'none' as empty."""
    if not flags_str or flags_str.strip().lower() == "none":
        return set()
    return {f.strip().lower() for f in flags_str.split(";") if f.strip()}


def compute_all_metrics(predicted_rows: list[dict], expected_rows: list[dict]) -> dict:
    """
    Compute all evaluation metrics comparing predicted vs expected rows.

    Args:
        predicted_rows: list of dicts from pipeline output
        expected_rows: list of dicts from sample_claims.csv (labeled)

    Returns:
        dict with metric names as keys and float scores as values
    """
    # Build parallel lists keyed by user_id + image_paths to ensure matching
    # (since user_id alone is not unique — some users appear multiple times)
    pred_by_key = {}
    for row in predicted_rows:
        key = (row["user_id"], row["image_paths"])
        pred_by_key[key] = row

    # Align predictions with expected rows
    pred_aligned = []
    exp_aligned = []
    for exp_row in expected_rows:
        key = (exp_row["user_id"], exp_row["image_paths"])
        if key in pred_by_key:
            pred_aligned.append(pred_by_key[key])
            exp_aligned.append(exp_row)

    if not pred_aligned:
        return {
            "claim_status_accuracy": 0.0,
            "evidence_standard_met_accuracy": 0.0,
            "valid_image_accuracy": 0.0,
            "severity_accuracy": 0.0,
            "issue_type_accuracy": 0.0,
            "object_part_accuracy": 0.0,
            "risk_flags_jaccard": 0.0,
            "matched_rows": 0,
        }

    metrics = {
        "claim_status_accuracy": accuracy(
            [r.get("claim_status", "") for r in pred_aligned],
            [r.get("claim_status", "") for r in exp_aligned]
        ),
        "evidence_standard_met_accuracy": accuracy(
            [r.get("evidence_standard_met", "") for r in pred_aligned],
            [r.get("evidence_standard_met", "") for r in exp_aligned]
        ),
        "valid_image_accuracy": accuracy(
            [r.get("valid_image", "") for r in pred_aligned],
            [r.get("valid_image", "") for r in exp_aligned]
        ),
        "severity_accuracy": accuracy(
            [r.get("severity", "") for r in pred_aligned],
            [r.get("severity", "") for r in exp_aligned]
        ),
        "issue_type_accuracy": accuracy(
            [r.get("issue_type", "") for r in pred_aligned],
            [r.get("issue_type", "") for r in exp_aligned]
        ),
        "object_part_accuracy": accuracy(
            [r.get("object_part", "") for r in pred_aligned],
            [r.get("object_part", "") for r in exp_aligned]
        ),
        "risk_flags_jaccard": jaccard_similarity(
            [r.get("risk_flags", "") for r in pred_aligned],
            [r.get("risk_flags", "") for r in exp_aligned]
        ),
        "matched_rows": len(pred_aligned),
    }

    return metrics
