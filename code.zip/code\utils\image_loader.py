"""
Image loader module.
Loads images from disk, base64-encodes for the Gemini API,
and runs pre-flight quality checks using Pillow.
"""

import base64
import os
from PIL import Image
import numpy as np


def check_image_quality(img: Image.Image) -> list[str]:
    """
    Run pre-flight quality checks on an image using Pillow.
    Returns a list of quality flag strings.
    """
    flags = []
    arr = np.array(img.convert("L"))  # grayscale

    # Blur detection: mean of horizontal and vertical pixel differences
    diff_h = np.abs(arr[:, 1:].astype(float) - arr[:, :-1].astype(float))
    diff_v = np.abs(arr[1:, :].astype(float) - arr[:-1, :].astype(float))
    sharpness = (diff_h.mean() + diff_v.mean()) / 2
    if sharpness < 3.0:
        flags.append("blurry_image")

    # Darkness detection: mean brightness
    mean_brightness = arr.mean()
    if mean_brightness < 40:
        flags.append("low_light_or_glare")

    # Extreme glare: very high mean brightness
    if mean_brightness > 230:
        flags.append("low_light_or_glare")

    # Very small image (likely cropped/thumbnail)
    w, h = img.size
    if w < 200 or h < 200:
        flags.append("cropped_or_obstructed")

    return flags


def load_images(image_paths_str: str, base_dir: str) -> list[dict]:
    """
    Load images from disk, base64-encode them, and run quality checks.

    Args:
        image_paths_str: semicolon-separated string of relative image paths
                         from CSV, e.g. "images/test/case_001/img_1.jpg;..."
        base_dir: the repo root directory (where dataset/ lives)

    Returns:
        list of dicts, one per successfully loaded image, with keys:
        image_id, path, base64_data, mime_type, quality_flags, width, height, file_size_kb
    """
    if not image_paths_str or not image_paths_str.strip():
        return []

    paths = [p.strip() for p in image_paths_str.split(";") if p.strip()]
    results = []

    for rel_path in paths:
        full_path = os.path.join(base_dir, "dataset", rel_path)
        full_path = os.path.normpath(full_path)

        # Extract image_id from filename (without extension)
        filename = os.path.basename(rel_path)
        image_id = os.path.splitext(filename)[0]

        try:
            # Get file size
            file_size_bytes = os.path.getsize(full_path)
            file_size_kb = round(file_size_bytes / 1024, 1)

            # Open with Pillow for quality checks and dimensions
            img = Image.open(full_path)
            img.load()  # force load to catch corrupt files
            width, height = img.size

            # Quality checks
            quality_flags = check_image_quality(img)

            # Base64 encode the raw bytes
            with open(full_path, "rb") as f:
                raw_bytes = f.read()
            b64_data = base64.b64encode(raw_bytes).decode("utf-8")

            # Determine MIME type
            ext = os.path.splitext(filename)[1].lower()
            mime_map = {
                ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg",
                ".png": "image/png",
                ".gif": "image/gif",
                ".webp": "image/webp",
            }
            mime_type = mime_map.get(ext, "image/jpeg")

            results.append({
                "image_id": image_id,
                "path": full_path,
                "base64_data": b64_data,
                "mime_type": mime_type,
                "quality_flags": quality_flags,
                "width": width,
                "height": height,
                "file_size_kb": file_size_kb,
            })

        except FileNotFoundError:
            print(f"    [WARN] Image not found: {full_path}")
        except Exception as e:
            print(f"    [WARN] Failed to load image {full_path}: {e}")

    return results
