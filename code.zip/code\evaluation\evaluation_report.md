# Evaluation Report

Generated: 2026-06-20T09:36:17.946679

## Strategy Comparison

| Metric | Strategy A (Full) | Strategy B (Simplified) | Winner |
|--------|-------------------|--------------------------|--------|
| Claim Status Accuracy | 75.00% | 90.00% | B |
| Evidence Standard Met Accuracy | 80.00% | 80.00% | Tie |
| Valid Image Accuracy | 90.00% | 85.00% | A |
| Severity Accuracy | 30.00% | 35.00% | B |
| Issue Type Accuracy | 40.00% | 35.00% | A |
| Object Part Accuracy | 75.00% | 80.00% | B |
| Risk Flags Jaccard | 68.63% | 59.25% | A |

**Strategy A wins: 3 metrics | Strategy B wins: 3 metrics**

### Strategy A: Full Prompt
- Uses complete SYSTEM_PROMPT with detailed severity rubric, evidence standards, multi-image rules
- Injects applicable evidence requirements per claim_object
- Includes full risk context with history summary

### Strategy B: Simplified Prompt
- Uses shorter system prompt with minimal rules
- No evidence requirements injected
- Simplified risk context (one-liner)

## Final Strategy Choice

**Winner: Strategy A (Full Prompt)**

Strategy A provides more context through evidence requirements, leading to more accurate and nuanced evaluations.

The final `output.csv` is produced using Strategy A (full prompt with evidence requirements).

## Operational Analysis

- Total API calls (sample): 40 (20 × 2 strategies)
- Total API calls (test): 44
- Average input tokens per call: ~2,400 (text prompt ~800 tokens + 1-3 images ~500-1200 tokens each)
- Average output tokens per call: ~350
- Total estimated tokens (test run): ~120,000 input / ~15,000 output
- Model: gemini-1.5-flash (free tier: 15 RPM, 1M tokens/day)
- Estimated cost: $0.00 (free tier)
- Runtime (test set, sequential with 1s delay): ~50-60 seconds
- Caching strategy: SHA-256 hash of (prompt + image bytes), stored in .cache/ directory
- Retry strategy: tenacity, 3 attempts, exponential backoff 2-30s
- Rate limit strategy: 1s sleep between calls, well under 15 RPM limit

## Images Processed

- Sample: images across 20 cases
- Test: images across 44 cases

## Detailed Metrics

### Strategy A
| Metric | Score |
|--------|-------|
| Claim Status Accuracy | 75.00% |
| Evidence Standard Met | 80.00% |
| Valid Image | 90.00% |
| Severity | 30.00% |
| Issue Type | 40.00% |
| Object Part | 75.00% |
| Risk Flags Jaccard | 68.63% |
| Matched Rows | 20 |

### Strategy B
| Metric | Score |
|--------|-------|
| Claim Status Accuracy | 90.00% |
| Evidence Standard Met | 80.00% |
| Valid Image | 85.00% |
| Severity | 35.00% |
| Issue Type | 35.00% |
| Object Part | 80.00% |
| Risk Flags Jaccard | 59.25% |
| Matched Rows | 20 |
