"""
Logger module.
Writes log entries to ~/hackerrank_orchestrate/log.txt per AGENTS.md §5 spec.
"""

import os
from datetime import datetime, timezone
from pathlib import Path

LOG_DIR = Path.home() / "hackerrank_orchestrate"
LOG_FILE = LOG_DIR / "log.txt"


def _get_time_remaining() -> str:
    """
    Compute time remaining until the challenge ends.
    Challenge end: 2026-06-20 11:00 IST (UTC+5:30).
    """
    try:
        from datetime import timedelta
        # Challenge end: 2026-06-20 11:00 IST = 2026-06-20 05:30 UTC
        ist = timezone(timedelta(hours=5, minutes=30))
        end_time = datetime(2026, 6, 20, 11, 0, 0, tzinfo=ist)
        now = datetime.now(tz=ist)
        remaining = end_time - now
        if remaining.total_seconds() <= 0:
            return "0d 0h 0m (challenge ended)"
        days = remaining.days
        hours, remainder = divmod(remaining.seconds, 3600)
        minutes = remainder // 60
        return f"{days}d {hours}h {minutes}m"
    except Exception:
        return "not configured"


def init_log():
    """
    Initialize the log file per AGENTS.md §2-§4.
    If onboarding has already been recorded for this repo root, append SESSION START.
    Otherwise, write the onboarding entry.
    """
    LOG_DIR.mkdir(exist_ok=True)
    repo_root = str(Path(__file__).parent.parent.parent.resolve())

    # Check if onboarding already done for THIS repo root
    if LOG_FILE.exists():
        content = LOG_FILE.read_text(encoding="utf-8")
        if f"AGREEMENT RECORDED: {repo_root}" in content:
            _append_session_start()
            return
    _write_onboarding()


def _write_onboarding():
    """Write the initial onboarding entry per AGENTS.md §3.4."""
    ts = datetime.now().isoformat()
    repo_root = str(Path(__file__).parent.parent.parent.resolve())
    time_remaining = _get_time_remaining()
    entry = f"""## [{ts}] ONBOARDING COMPLETE

AGREEMENT RECORDED: {repo_root}
Agent: antigravity-ai-agent
Language: py
System Time: {ts}
Time Remaining: {time_remaining}
"""
    _append(entry)


def _append_session_start():
    """Write a session start entry per AGENTS.md §5.1."""
    ts = datetime.now().isoformat()
    repo_root = str(Path(__file__).parent.parent.parent.resolve())
    time_remaining = _get_time_remaining()

    # Try to get git branch
    branch = "unknown"
    try:
        import subprocess
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, cwd=repo_root, timeout=5
        )
        if result.returncode == 0:
            branch = result.stdout.strip()
    except Exception:
        pass

    entry = f"""## [{ts}] SESSION START

Agent: antigravity-ai-agent
Repo Root: {repo_root}
Branch: {branch}
Worktree: main
Parent Agent: none
Language: py
Time Remaining: {time_remaining}
"""
    _append(entry)


def log_turn(title: str, user_prompt_summary: str, response_summary: str, actions: list[str]):
    """
    Log a single turn per AGENTS.md §5.2.

    Args:
        title: Short title for this turn (max 80 chars)
        user_prompt_summary: The user prompt (verbatim where possible, secrets redacted)
        response_summary: 2-5 sentence summary of what was done
        actions: List of action descriptions taken
    """
    ts = datetime.now().isoformat()
    repo_root = str(Path(__file__).parent.parent.parent.resolve())

    # Try to get git branch
    branch = "unknown"
    try:
        import subprocess
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, cwd=repo_root, timeout=5
        )
        if result.returncode == 0:
            branch = result.stdout.strip()
    except Exception:
        pass

    actions_text = "".join(f"* {a}\n" for a in actions)
    entry = f"""## [{ts}] {title[:80]}

User Prompt (verbatim, secrets redacted):
{user_prompt_summary}

Agent Response Summary:
{response_summary}

Actions:
{actions_text}
Context:
tool=antigravity-ai-agent
branch={branch}
repo_root={repo_root}
worktree=main
parent_agent=none
"""
    _append(entry)


def _append(text: str):
    """
    Append text to the log file.
    Uses UTF-8 encoding with explicit \\n line endings (no \\r\\n)
    per AGENTS.md §7.
    """
    LOG_DIR.mkdir(exist_ok=True)
    # Open in binary mode and write \n explicitly to avoid \r\n on Windows
    with open(LOG_FILE, "ab") as f:
        f.write((text + "\n").encode("utf-8"))
