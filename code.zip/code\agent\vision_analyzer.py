"""
Vision analyzer module.
Calls Google Gemini API with robust retry handling for rate limits.
Includes file-based caching to avoid duplicate API calls.

Uses the google-genai SDK (pip install google-genai).
"""

import base64
import hashlib
import json
import os
import re
import time

from google import genai
from google.genai import types

from agent.prompts import SYSTEM_PROMPT


def analyze_claim(text_prompt: str, images: list[dict], system_prompt: str = None) -> dict:
    """
    Send a claim analysis request to the Gemini API with robust retry handling.
    Retries up to 5 times with 60s waits for rate limit (429) errors.

    Args:
        text_prompt: the assembled text prompt from build_user_prompt
        images: list of dicts with keys: base64_data, mime_type, image_id
        system_prompt: optional override for the system prompt (for Strategy B)

    Returns:
        Parsed dict matching output schema fields.
    """
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("GEMINI_API_KEY environment variable is not set.")

    client = genai.Client(api_key=api_key)
    sys_prompt = system_prompt if system_prompt is not None else SYSTEM_PROMPT

    # Build content: plain string for text, Part objects for images
    contents = [text_prompt]
    for img in images:
        raw_bytes = base64.b64decode(img["base64_data"])
        contents.append(types.Part.from_bytes(
            data=raw_bytes,
            mime_type=img["mime_type"]
        ))

    # Retry loop with rate limit handling
    max_retries = 6
    for attempt in range(1, max_retries + 1):
        try:
            response = client.models.generate_content(
                model="gemini-3.1-flash-lite",
                contents=contents,
                config=types.GenerateContentConfig(
                    system_instruction=sys_prompt,
                ),
            )

            raw_text = response.text.strip()

            # Parse JSON — strip any accidental markdown fences
            clean = re.sub(r"^```(?:json)?|```$", "", raw_text, flags=re.MULTILINE).strip()
            result = json.loads(clean)
            return result

        except Exception as e:
            error_str = str(e)
            if "429" in error_str or "RESOURCE_EXHAUSTED" in error_str:
                # Extract retry delay from error message if available
                wait_time = 65  # default wait
                try:
                    import re as regex
                    match = regex.search(r"retry in (\d+(?:\.\d+)?)s", error_str, regex.IGNORECASE)
                    if match:
                        wait_time = max(int(float(match.group(1))) + 5, 30)
                except Exception:
                    pass

                if attempt < max_retries:
                    print(f"    [RATE LIMIT] Attempt {attempt}/{max_retries}: waiting {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    print(f"    [RATE LIMIT] All {max_retries} attempts exhausted.")
                    raise
            else:
                print(f"    [ERROR] Attempt {attempt}: {type(e).__name__}: {error_str[:200]}")
                if attempt < max_retries:
                    time.sleep(5)
                else:
                    raise


# --- Caching helpers ---

def get_cache_key(text_prompt: str, images: list[dict]) -> str:
    """Generate a short SHA-256 hash key for caching."""
    hasher = hashlib.sha256()
    hasher.update(text_prompt.encode("utf-8"))
    for img in images:
        hasher.update(img["base64_data"].encode("utf-8"))
    return hasher.hexdigest()[:16]


def load_from_cache(cache_key: str, cache_dir: str) -> dict | None:
    """Load a cached response if it exists."""
    path = os.path.join(cache_dir, f"{cache_key}.json")
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None
    return None


def save_to_cache(cache_key: str, data: dict, cache_dir: str):
    """Save a response to the file-based cache."""
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, f"{cache_key}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
