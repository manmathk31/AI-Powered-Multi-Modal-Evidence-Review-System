#!/usr/bin/env python3
"""
Main entry point.
Usage: python code/main.py [--no-cache] [--base-dir .]
Reads dataset/claims.csv, writes output.csv
"""

import argparse
import os
import sys
import time

from dotenv import load_dotenv

load_dotenv()

# Add code/ to sys.path so imports work correctly
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.csv_io import read_claims, read_user_history, write_output
from utils.logger import init_log, log_turn
from agent.claim_processor import process_claim


def make_error_row(row: dict) -> dict:
    """Fallback row if processing fails completely."""
    return {
        "user_id": row["user_id"],
        "image_paths": row["image_paths"],
        "user_claim": row["user_claim"],
        "claim_object": row["claim_object"],
        "evidence_standard_met": "false",
        "evidence_standard_met_reason": "Processing error.",
        "risk_flags": "manual_review_required",
        "issue_type": "unknown",
        "object_part": "unknown",
        "claim_status": "not_enough_information",
        "claim_status_justification": "Processing error — manual review required.",
        "supporting_image_ids": "none",
        "valid_image": "false",
        "severity": "unknown",
    }


def main():
    parser = argparse.ArgumentParser(description="Multi-Modal Evidence Review Pipeline")
    parser.add_argument("--base-dir", default=".", help="Repo root directory")
    parser.add_argument("--no-cache", action="store_true", help="Skip response cache")
    args = parser.parse_args()

    base_dir = os.path.abspath(args.base_dir)
    claims_path = os.path.join(base_dir, "dataset", "claims.csv")
    history_path = os.path.join(base_dir, "dataset", "user_history.csv")
    output_path = os.path.join(base_dir, "output.csv")
    cache_dir = os.path.join(base_dir, ".cache")

    # Initialize logger
    init_log()

    # Read inputs
    claims = read_claims(claims_path)
    user_history = read_user_history(history_path)

    print(f"Processing {len(claims)} claims...")
    results = []
    for i, row in enumerate(claims, 1):
        claim_summary = f"{row['user_id']} | {row['claim_object']} | {row['image_paths'][:50]}..."
        print(f"  [{i}/{len(claims)}] {claim_summary}")
        try:
            result = process_claim(
                row, user_history, base_dir, cache_dir,
                use_cache=not args.no_cache
            )
            results.append(result)

            # Log this turn
            log_turn(
                title=f"Processed claim {i}/{len(claims)}: {row['user_id']}",
                user_prompt_summary=f"Claim from {row['user_id']} for {row['claim_object']}",
                response_summary=f"Status: {result.get('claim_status', 'unknown')}, "
                                 f"Severity: {result.get('severity', 'unknown')}",
                actions=[
                    f"Loaded images from {row['image_paths'][:60]}",
                    f"Called Gemini API for {row['claim_object']} claim",
                    f"Result: {result.get('claim_status', 'unknown')}"
                ]
            )

        except Exception as e:
            print(f"    ERROR: {e}")
            results.append(make_error_row(row))

            log_turn(
                title=f"ERROR processing claim {i}/{len(claims)}: {row['user_id']}",
                user_prompt_summary=f"Claim from {row['user_id']} for {row['claim_object']}",
                response_summary=f"Error: {str(e)[:200]}",
                actions=[f"Error occurred: {str(e)[:200]}", "Used fallback error row"]
            )

        time.sleep(5.0)  # Rate limit: stay under 15 RPM free tier (gemini-2.0-flash)

    write_output(results, output_path)
    print(f"\nDone. Written {len(results)} rows to {output_path}")


if __name__ == "__main__":
    main()
