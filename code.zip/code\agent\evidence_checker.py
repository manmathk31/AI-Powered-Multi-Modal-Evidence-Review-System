"""
Evidence checker module.
Matches claim_object to the applicable evidence requirements
and returns them as a formatted string for prompt injection.
"""

# Hardcoded evidence requirements — never re-read per claim
EVIDENCE_REQUIREMENTS = {
    "REQ_GENERAL_OBJECT_PART": {
        "applies_to": ["all"],
        "rule": "The claimed object and relevant part should be visible clearly enough to inspect the claimed condition."
    },
    "REQ_GENERAL_MULTI_IMAGE": {
        "applies_to": ["all"],
        "rule": "Each submitted image should be considered separately; at least one relevant image should show the claimed object or part clearly enough to evaluate the claim."
    },
    "REQ_CAR_BODY_PANEL": {
        "applies_to": ["car"],
        "rule": "The claimed car panel or bumper should be visible from an angle where surface marks or deformation can be assessed."
    },
    "REQ_CAR_GLASS_LIGHT_MIRROR": {
        "applies_to": ["car"],
        "rule": "The claimed glass, light, mirror, or component should be visible clearly enough to inspect cracks, breakage, or missing parts."
    },
    "REQ_CAR_IDENTITY_OR_SIDE": {
        "applies_to": ["car"],
        "rule": "When the claim depends on vehicle identity, side, or orientation, the image set should show enough context to match the claimed vehicle and part."
    },
    "REQ_LAPTOP_SCREEN_KEYBOARD_TRACKPAD": {
        "applies_to": ["laptop"],
        "rule": "The claimed laptop screen, keyboard, or trackpad area should be visible clearly enough to inspect cracks, stains, missing keys, or surface damage."
    },
    "REQ_LAPTOP_BODY_HINGE_PORT": {
        "applies_to": ["laptop"],
        "rule": "The claimed laptop hinge, lid, corner, body, base, or port should be visible with enough context to identify the relevant laptop part."
    },
    "REQ_PACKAGE_EXTERIOR": {
        "applies_to": ["package"],
        "rule": "The package exterior and claimed side, corner, flap, or seal should be visible clearly enough to inspect packaging damage."
    },
    "REQ_PACKAGE_LABEL_OR_STAIN": {
        "applies_to": ["package"],
        "rule": "The affected package surface or label should be visible clearly enough to assess stain, water damage, label readability, or label damage."
    },
    "REQ_PACKAGE_CONTENTS": {
        "applies_to": ["package"],
        "rule": "The opened package and relevant contents area should be visible clearly enough to assess missing or damaged items."
    },
    "REQ_REVIEW_TRUST": {
        "applies_to": ["all"],
        "rule": "The submitted images should provide visual evidence that is usable, relevant to the claim, and grounded in the claimed object."
    }
}


def get_applicable_requirements(claim_object: str) -> str:
    """
    Returns a formatted string of all evidence rules that apply to this
    claim_object (both 'all' rules and object-specific rules).
    Used directly in the prompt.

    Args:
        claim_object: one of "car", "laptop", "package"

    Returns:
        Formatted multi-line string of applicable evidence requirements
    """
    lines = []
    for req_id, req in EVIDENCE_REQUIREMENTS.items():
        applies = req["applies_to"]
        if "all" in applies or claim_object in applies:
            lines.append(f"  - [{req_id}] {req['rule']}")

    return "\n".join(lines)
