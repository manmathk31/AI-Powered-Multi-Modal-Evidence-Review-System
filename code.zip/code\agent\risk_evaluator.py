"""
Risk evaluator module.
Given a user_id and user history dict, computes risk signals
to inject into the Gemini prompt.
"""


def evaluate_risk(user_id: str, history: dict) -> dict:
    """
    Evaluate risk signals for a user based on their claim history.

    Args:
        user_id: the user identifier
        history: dict keyed by user_id from user_history.csv

    Returns:
        dict with keys:
            has_history_risk: bool
            needs_manual_review: bool
            rejection_rate: float (rejected / total if total > 0, else 0.0)
            recent_activity: int (last_90_days_claim_count)
            history_summary: str (human-readable summary)
            risk_flags_to_add: list[str] (flags to include regardless of image result)
    """
    # Default: no risk
    defaults = {
        "has_history_risk": False,
        "needs_manual_review": False,
        "rejection_rate": 0.0,
        "recent_activity": 0,
        "history_summary": "No history available for this user.",
        "risk_flags_to_add": [],
    }

    if user_id not in history:
        return defaults

    user_data = history[user_id]
    history_flags_raw = user_data.get("history_flags", "none")
    history_flags = set()
    if history_flags_raw and history_flags_raw.strip() != "none":
        history_flags = {f.strip() for f in history_flags_raw.split(";")}

    has_history_risk = "user_history_risk" in history_flags
    needs_manual_review = "manual_review_required" in history_flags

    risk_flags_to_add = []
    if has_history_risk:
        risk_flags_to_add.append("user_history_risk")
    if needs_manual_review:
        risk_flags_to_add.append("manual_review_required")

    # Compute rejection rate
    past_claim_count = int(user_data.get("past_claim_count", "0") or "0")
    rejected_claim = int(user_data.get("rejected_claim", "0") or "0")
    rejection_rate = rejected_claim / past_claim_count if past_claim_count > 0 else 0.0

    # Recent activity
    recent_activity = int(user_data.get("last_90_days_claim_count", "0") or "0")

    # History summary
    history_summary = user_data.get("history_summary", "No summary available.")

    return {
        "has_history_risk": has_history_risk,
        "needs_manual_review": needs_manual_review,
        "rejection_rate": rejection_rate,
        "recent_activity": recent_activity,
        "history_summary": history_summary,
        "risk_flags_to_add": risk_flags_to_add,
    }
