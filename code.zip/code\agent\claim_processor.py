"""
Claim processor module.
Orchestrates one full claim → one output row.
"""

from utils.image_loader import load_images
from agent.risk_evaluator import evaluate_risk
from agent.evidence_checker import get_applicable_requirements
from agent.prompts import build_user_prompt
from agent.vision_analyzer import (
    analyze_claim,
    get_cache_key,
    load_from_cache,
    save_to_cache,
)


# --- Allowed value sets for validation ---

VALID_CLAIM_STATUS = {"supported", "contradicted", "not_enough_information"}
VALID_ISSUE_TYPES = {
    "dent", "scratch", "crack", "glass_shatter", "broken_part", "missing_part",
    "torn_packaging", "crushed_packaging", "water_damage", "stain", "none", "unknown"
}
VALID_SEVERITY = {"none", "low", "medium", "high", "unknown"}
VALID_RISK_FLAGS = {
    "blurry_image", "cropped_or_obstructed", "low_light_or_glare", "wrong_angle",
    "wrong_object", "wrong_object_part", "damage_not_visible", "claim_mismatch",
    "possible_manipulation", "non_original_image", "text_instruction_present",
    "user_history_risk", "manual_review_required", "none"
}

CAR_PARTS = {
    "front_bumper", "rear_bumper", "door", "hood", "windshield", "side_mirror",
    "headlight", "taillight", "fender", "quarter_panel", "body", "unknown"
}
LAPTOP_PARTS = {
    "screen", "keyboard", "trackpad", "hinge", "lid", "corner", "port", "base",
    "body", "unknown"
}
PACKAGE_PARTS = {
    "box", "package_corner", "package_side", "seal", "label", "contents", "item",
    "unknown"
}

VALID_PARTS = {"car": CAR_PARTS, "laptop": LAPTOP_PARTS, "package": PACKAGE_PARTS}


def validate_output(raw: dict, claim_object: str) -> dict:
    """
    Validate all fields from the API response against allowed values.
    Substitute safe fallbacks for any invalid values. Never crash on bad API output.

    Args:
        raw: dict parsed from the Gemini API JSON response
        claim_object: "car", "laptop", or "package"

    Returns:
        dict with all 10 output fields (excluding the 4 pass-through input columns)
    """
    def pick(val, valid_set, fallback):
        return val if val in valid_set else fallback

    def pick_bool(val):
        if isinstance(val, bool):
            return str(val).lower()
        if str(val).lower() in ("true", "false"):
            return str(val).lower()
        return "false"

    valid_parts = VALID_PARTS.get(claim_object, set()) | {"unknown"}

    # Validate risk_flags
    raw_flags = raw.get("risk_flags", "none")
    if raw_flags and raw_flags != "none":
        flag_list = [f.strip() for f in str(raw_flags).split(";")]
        valid_flag_list = [f for f in flag_list if f in VALID_RISK_FLAGS]
        clean_flags = ";".join(valid_flag_list) if valid_flag_list else "none"
    else:
        clean_flags = "none"

    return {
        "evidence_standard_met": pick_bool(raw.get("evidence_standard_met", "false")),
        "evidence_standard_met_reason": str(raw.get("evidence_standard_met_reason", "Unable to determine."))[:300],
        "risk_flags": clean_flags,
        "issue_type": pick(raw.get("issue_type", "unknown"), VALID_ISSUE_TYPES, "unknown"),
        "object_part": pick(raw.get("object_part", "unknown"), valid_parts, "unknown"),
        "claim_status": pick(raw.get("claim_status", "not_enough_information"), VALID_CLAIM_STATUS, "not_enough_information"),
        "claim_status_justification": str(raw.get("claim_status_justification", "Unable to determine."))[:500],
        "supporting_image_ids": str(raw.get("supporting_image_ids", "none")),
        "valid_image": pick_bool(raw.get("valid_image", "false")),
        "severity": pick(raw.get("severity", "unknown"), VALID_SEVERITY, "unknown"),
    }


def process_claim(
    row: dict,
    user_history: dict,
    base_dir: str,
    cache_dir: str,
    use_cache: bool = True,
    system_prompt_override: str = None,
    build_prompt_fn=None,
) -> dict:
    """
    Process one claim row end-to-end: load images, evaluate risk,
    build prompt, call API, validate, and return the complete output row.

    Args:
        row: one dict from claims.csv (keys: user_id, image_paths, user_claim, claim_object)
        user_history: dict keyed by user_id from user_history.csv
        base_dir: repo root directory
        cache_dir: path to the .cache/ directory
        use_cache: whether to use file-based response caching
        system_prompt_override: optional override for the system prompt (for Strategy B)
        build_prompt_fn: optional override for prompt building function (for Strategy B)

    Returns:
        Complete output row dict with all 14 columns
    """
    # Step 1: Load images
    images = load_images(row["image_paths"], base_dir)
    image_ids = [img["image_id"] for img in images]
    quality_flags = {img["image_id"]: img["quality_flags"] for img in images}

    # Step 2: Risk evaluation
    risk = evaluate_risk(row["user_id"], user_history)

    # Step 3: Evidence requirements
    evidence_text = get_applicable_requirements(row["claim_object"])

    # Step 4: Build prompt (use override if provided)
    if build_prompt_fn is not None:
        text_prompt = build_prompt_fn(
            claim_object=row["claim_object"],
            user_claim=row["user_claim"],
            image_ids=image_ids,
            quality_flags_per_image=quality_flags,
            risk_context=risk,
        )
    else:
        text_prompt = build_user_prompt(
            claim_object=row["claim_object"],
            user_claim=row["user_claim"],
            image_ids=image_ids,
            quality_flags_per_image=quality_flags,
            risk_context=risk,
            evidence_requirements_text=evidence_text,
        )

    # Step 5: API call (with cache)
    cache_key = get_cache_key(text_prompt, images)
    api_result = None
    if use_cache:
        api_result = load_from_cache(cache_key, cache_dir)
    if api_result is None:
        api_result = analyze_claim(text_prompt, images, system_prompt=system_prompt_override)
        if use_cache:
            save_to_cache(cache_key, api_result, cache_dir)

    # Step 6: Merge risk flags from history with API-returned flags
    api_flags_raw = api_result.get("risk_flags", "none")
    api_flags = set(api_flags_raw.split(";")) if api_flags_raw != "none" else set()
    history_flags = set(risk["risk_flags_to_add"])
    all_flags = api_flags | history_flags
    # Remove "none" if real flags exist
    all_flags.discard("none")
    final_flags = ";".join(sorted(all_flags)) if all_flags else "none"

    # Step 7: Validate all fields against allowed values
    validated = validate_output(api_result, row["claim_object"])
    validated["risk_flags"] = final_flags

    # Step 8: Build full output row (pass through input columns)
    output_row = {
        "user_id": row["user_id"],
        "image_paths": row["image_paths"],
        "user_claim": row["user_claim"],
        "claim_object": row["claim_object"],
        **validated
    }

    return output_row
